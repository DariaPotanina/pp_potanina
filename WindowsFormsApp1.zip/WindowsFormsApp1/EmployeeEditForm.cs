﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class EmployeeEditForm : Form
    {
        private const string ConnectionString = @"Data Source=LAPTOP-TPFTDA5B;Initial Catalog=pp_potanina;Integrated Security=True;Encrypt=False;TrustServerCertificate=True;";
        private int _employeeId;

        // Конструктор с передачей ID сотрудника
        public EmployeeEditForm(int employeeId)
        {
            InitializeComponent();
            _employeeId = employeeId;
            InitializeDataGridView();
            LoadReferenceData();
            LoadEmployeeData();
            LoadContacts();
        }

        // Пустой конструктор (на случай, если вызывают без ID)
        public EmployeeEditForm()
        {
            InitializeComponent();
            InitializeDataGridView();
            LoadReferenceData();
        }

        private void InitializeDataGridView()
        {
            dgvContacts.AutoGenerateColumns = false;
            dgvContacts.Columns.Clear();

            // Столбец: Тип контакта (ComboBox)
            var colType = new DataGridViewComboBoxColumn();
            colType.Name = "ContactType";
            colType.HeaderText = "Тип контакта";
            colType.DisplayMember = "НазваниеТипа";
            colType.ValueMember = "Идентификатор";
            colType.DataSource = GetContactTypes();
            dgvContacts.Columns.Add(colType);

            // Столбец: Значение
            dgvContacts.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Value",
                HeaderText = "Значение",
                Width = 200
            });

            // Столбец: Удалить
            dgvContacts.Columns.Add(new DataGridViewButtonColumn
            {
                Name = "Delete",
                HeaderText = "Действие",
                Text = "Удалить",
                UseColumnTextForButtonValue = true,
                Width = 80
            });
        }

        private DataTable GetContactTypes()
        {
            var dt = new DataTable();
            string sql = "SELECT [Идентификатор], [НазваниеТипа] FROM [ТипыКонтактов]";
            using (var conn = new SqlConnection(ConnectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                using (var da = new SqlDataAdapter(cmd))
                    da.Fill(dt);
            }
            return dt;
        }

        private void LoadReferenceData()
        {
            // Должности
            string sqlPos = "SELECT [Идентификатор], [НазваниеДолжности] FROM [Должности]";
            cmbPosition.DisplayMember = "НазваниеДолжности";
            cmbPosition.ValueMember = "Идентификатор";
            cmbPosition.DataSource = GetData(sqlPos);

            // Подразделения
            string sqlDept = "SELECT [Идентификатор], [НазваниеОтдела] FROM [Подразделения]";
            cmbDepartment.DisplayMember = "НазваниеОтдела";
            cmbDepartment.ValueMember = "Идентификатор";
            cmbDepartment.DataSource = GetData(sqlDept);
        }

        private DataTable GetData(string sql)
        {
            var dt = new DataTable();
            using (var conn = new SqlConnection(ConnectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                using (var da = new SqlDataAdapter(cmd))
                    da.Fill(dt);
            }
            return dt;
        }

        private void LoadEmployeeData()
        {
            if (_employeeId <= 0) return;

            string sql = @"
SELECT [ФИО], [ИдДолжности], [ИдПодразделения], [Корпус], [НомерКабинета]
FROM [Сотрудники]
WHERE [Идентификатор] = @id";

            using (var conn = new SqlConnection(ConnectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@id", _employeeId);
                conn.Open();
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtFIO.Text = reader["ФИО"].ToString();
                    cmbPosition.SelectedValue = reader["ИдДолжности"];
                    cmbDepartment.SelectedValue = reader["ИдПодразделения"];
                    txtBuilding.Text = reader["Корпус"]?.ToString();
                    txtRoom.Text = reader["НомерКабинета"]?.ToString();
                }
                reader.Close();
            }
        }

        private void LoadContacts()
        {
            if (_employeeId <= 0) return;

            string sql = @"
SELECT c.[Идентификатор] AS ContactId, c.[ИдТипаКонтакта], c.[Значение]
FROM [Контакты] c
WHERE c.[ИдСотрудника] = @empId";

            var dt = new DataTable();
            dt.Columns.Add("ContactId", typeof(int));
            dt.Columns.Add("ИдТипаКонтакта", typeof(int));
            dt.Columns.Add("Значение", typeof(string));

            using (var conn = new SqlConnection(ConnectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@empId", _employeeId);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        dt.Rows.Add(
                            reader["ContactId"],
                            reader["ИдТипаКонтакта"],
                            reader["Значение"]
                        );
                    }
                }
            }

            // Привязываем к DataGridView
            dgvContacts.DataSource = dt;
        }

        private void btnAddContact_Click(object sender, EventArgs e)
        {
            var dt = dgvContacts.DataSource as DataTable;
            if (dt == null)
            {
                dt = new DataTable();
                dt.Columns.Add("ContactId", typeof(int));
                dt.Columns.Add("ИдТипаКонтакта", typeof(int));
                dt.Columns.Add("Значение", typeof(string));
            }

            // Добавляем новую строку (ContactId = 0 — признак нового)
            dt.Rows.Add(0, 1, ""); // 1 — первый тип из списка
            dgvContacts.DataSource = dt;
        }

        private void dgvContacts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (dgvContacts.Columns[e.ColumnIndex].Name == "Delete")
            {
                dgvContacts.Rows.RemoveAt(e.RowIndex);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_employeeId <= 0)
            {
                MessageBox.Show("Невозможно сохранить: не указан ID сотрудника.");
                return;
            }

            try
            {
                using (var conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();

                    // Обновляем основные данные
                    string sql = @"
UPDATE [Сотрудники] 
SET [ФИО] = @fio,
    [ИдДолжности] = @pos,
    [ИдПодразделения] = @dept,
    [Корпус] = @building,
    [НомерКабинета] = @room
WHERE [Идентификатор] = @id";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@fio", txtFIO.Text.Trim());
                        cmd.Parameters.AddWithValue("@pos", cmbPosition.SelectedValue);
                        cmd.Parameters.AddWithValue("@dept", cmbDepartment.SelectedValue);
                        cmd.Parameters.AddWithValue("@building", txtBuilding.Text.Trim());
                        cmd.Parameters.AddWithValue("@room", txtRoom.Text.Trim());
                        cmd.Parameters.AddWithValue("@id", _employeeId);
                        cmd.ExecuteNonQuery();
                    }

                    // Удаляем старые контакты
                    using (var cmd = new SqlCommand("DELETE FROM [Контакты] WHERE [ИдСотрудника] = @empId", conn))
                    {
                        cmd.Parameters.AddWithValue("@empId", _employeeId);
                        cmd.ExecuteNonQuery();
                    }

                    // Добавляем новые контакты
                    var dt = dgvContacts.DataSource as DataTable;
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            string value = row["Значение"]?.ToString().Trim();
                            if (string.IsNullOrEmpty(value)) continue;

                            using (var cmd = new SqlCommand(@"
INSERT INTO [Контакты] ([ИдСотрудника], [ИдТипаКонтакта], [Значение])
VALUES (@empId, @typeId, @value)", conn))
                            {
                                cmd.Parameters.AddWithValue("@empId", _employeeId);
                                cmd.Parameters.AddWithValue("@typeId", row["ИдТипаКонтакта"]);
                                cmd.Parameters.AddWithValue("@value", value);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }

                    MessageBox.Show("Данные успешно сохранены!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Пустые обработчики (можно удалить)
        private void txtFIO_TextChanged(object sender, EventArgs e) { }
        private void cmbPosition_SelectedIndexChanged(object sender, EventArgs e) { }
        private void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e) { }
        private void txtBuilding_TextChanged(object sender, EventArgs e) { }
        private void txtRoom_TextChanged(object sender, EventArgs e) { }
    }
}