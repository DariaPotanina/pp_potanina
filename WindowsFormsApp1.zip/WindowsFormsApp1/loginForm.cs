﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class loginForm : Form
    {
        private const string ConnectionString = @"Data Source=LAPTOP-TPFTDA5B;Initial Catalog=pp_potanina;Integrated Security=True;Encrypt=False;TrustServerCertificate=True;";

        public loginForm()
        {
            InitializeComponent();
            // Заполняем ComboBox ролями при запуске
            comboBox1.Items.Add("Администратор");
            comboBox1.Items.Add("Абонент");
            comboBox1.SelectedIndex = 0; // по умолчанию — Администратор
        }

        private void enter_button1_Click(object sender, EventArgs e)
        {
            string login = login_textBox1.Text.Trim();
            string password = parol_textBox1.Text;
            string selectedRole = comboBox1.SelectedItem?.ToString();

            // Проверка ввода
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин и пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (selectedRole != "Администратор" && selectedRole != "Абонент")
            {
                MessageBox.Show("Выберите роль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Проверяем учётную запись в БД (простая проверка пароля = "12345")
            string sql = @"
SELECT [ИдСотрудника] 
FROM [Пользователи] 
WHERE [Логин] = @login 
  AND [Роль] = @role";

            using (var conn = new SqlConnection(ConnectionString))
            {
                try
                {
                    conn.Open();
                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@login", login);
                        cmd.Parameters.AddWithValue("@role", selectedRole);

                        var result = cmd.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            // Проверяем пароль (в учебных целях — одинаковый для всех)
                            if (password == "12345")
                            {
                                int employeeId = Convert.ToInt32(result);

                                // Открываем главную форму
                                var main = new mainForm
                                {
                                    CurrentUserLogin = login,
                                    CurrentUserRole = selectedRole,
                                    CurrentEmployeeId = employeeId
                                };
                                main.Show();
                                this.Hide(); // скрываем форму входа
                                return;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка подключения к БД:\n{ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // Если дошли сюда — вход не удался
            MessageBox.Show("Неверный логин, пароль или роль.", "Ошибка входа",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void clean_button2_Click(object sender, EventArgs e)
        {
            // Очищаем форму
            login_textBox1.Clear();
            parol_textBox1.Clear();
            comboBox1.SelectedIndex = 0;
            login_textBox1.Focus();
        }

        // Остальные обработчики оставляем пустыми (или можно удалить)
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void login_textBox1_TextChanged(object sender, EventArgs e) { }
        private void parol_textBox1_TextChanged(object sender, EventArgs e) { }
    }
}