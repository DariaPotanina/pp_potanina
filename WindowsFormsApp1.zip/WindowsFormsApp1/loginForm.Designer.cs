﻿namespace WindowsFormsApp1
{
    partial class loginForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.enter_button1 = new System.Windows.Forms.Button();
            this.clean_button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.login_textBox1 = new System.Windows.Forms.TextBox();
            this.parol_textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("NSimSun", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(298, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Авторизация";
            // 
            // enter_button1
            // 
            this.enter_button1.FlatAppearance.BorderSize = 2;
            this.enter_button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.enter_button1.Font = new System.Drawing.Font("Garamond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enter_button1.Location = new System.Drawing.Point(213, 344);
            this.enter_button1.Name = "enter_button1";
            this.enter_button1.Size = new System.Drawing.Size(137, 29);
            this.enter_button1.TabIndex = 1;
            this.enter_button1.Text = "Войти";
            this.enter_button1.UseVisualStyleBackColor = true;
            this.enter_button1.Click += new System.EventHandler(this.enter_button1_Click);
            // 
            // clean_button2
            // 
            this.clean_button2.FlatAppearance.BorderSize = 2;
            this.clean_button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clean_button2.Font = new System.Drawing.Font("Garamond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clean_button2.Location = new System.Drawing.Point(42, 344);
            this.clean_button2.Name = "clean_button2";
            this.clean_button2.Size = new System.Drawing.Size(127, 29);
            this.clean_button2.TabIndex = 2;
            this.clean_button2.Text = "Отменить";
            this.clean_button2.UseVisualStyleBackColor = true;
            this.clean_button2.Click += new System.EventHandler(this.clean_button2_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(60, 147);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(267, 24);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Garamond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(105, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 22);
            this.label2.TabIndex = 4;
            this.label2.Text = "Выберите должность";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Garamond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(155, 192);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 22);
            this.label3.TabIndex = 5;
            this.label3.Text = "Логин";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Garamond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(146, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 22);
            this.label4.TabIndex = 6;
            this.label4.Text = "Пароль";
            // 
            // login_textBox1
            // 
            this.login_textBox1.Location = new System.Drawing.Point(60, 217);
            this.login_textBox1.Name = "login_textBox1";
            this.login_textBox1.Size = new System.Drawing.Size(267, 22);
            this.login_textBox1.TabIndex = 7;
            this.login_textBox1.TextChanged += new System.EventHandler(this.login_textBox1_TextChanged);
            // 
            // parol_textBox1
            // 
            this.parol_textBox1.Location = new System.Drawing.Point(60, 280);
            this.parol_textBox1.Name = "parol_textBox1";
            this.parol_textBox1.Size = new System.Drawing.Size(267, 22);
            this.parol_textBox1.TabIndex = 8;
            this.parol_textBox1.TextChanged += new System.EventHandler(this.parol_textBox1_TextChanged);
            // 
            // loginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 419);
            this.Controls.Add(this.parol_textBox1);
            this.Controls.Add(this.login_textBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.clean_button2);
            this.Controls.Add(this.enter_button1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "loginForm";
            this.Text = "loginForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button enter_button1;
        private System.Windows.Forms.Button clean_button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox login_textBox1;
        private System.Windows.Forms.TextBox parol_textBox1;
    }
}

