﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class mainForm : Form
    {
        private const string ConnectionString = @"Data Source=LAPTOP-TPFTDA5B;Initial Catalog=pp_potanina;Integrated Security=True;Encrypt=False;TrustServerCertificate=True;";

        // Данные текущего пользователя (передаются из LoginForm)
        public string CurrentUserLogin { get; set; } = "Тест";
        public string CurrentUserRole { get; set; } = "Абонент";
        public int CurrentEmployeeId { get; set; } = 1;

        public mainForm()
        {
            InitializeComponent();
            this.Load += mainForm_Load;
            SetupDataGridView();
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = $"Вы вошли как: {CurrentUserLogin} ({CurrentUserRole})";
            LoadAllEmployees();
        }

        private void SetupDataGridView()
        {
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.Columns.Clear();

            // Скрытый ID
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ColEmployeeId",
                DataPropertyName = "EmployeeId",
                Visible = false
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ColFIO",
                DataPropertyName = "ФИО",
                HeaderText = "ФИО",
                Width = 200
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ColPosition",
                DataPropertyName = "Должность",
                HeaderText = "Должность",
                Width = 150
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ColDepartment",
                DataPropertyName = "Подразделение",
                HeaderText = "Подразделение",
                Width = 150
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ColRoom",
                DataPropertyName = "Кабинет",
                HeaderText = "Корпус / Кабинет",
                Width = 120
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ColPhones",
                DataPropertyName = "Телефоны",
                HeaderText = "Телефоны",
                Width = 150
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ColEmails",
                DataPropertyName = "Emails",
                HeaderText = "Email",
                Width = 180
            });

            dataGridView1.Columns.Add(new DataGridViewButtonColumn
            {
                Name = "EditButton",
                Text = "Редактировать",
                UseColumnTextForButtonValue = true,
                Width = 120
            });
        }

        private void LoadAllEmployees(string search = null)
        {

            var dt = new DataTable();
            dt.Columns.Add("EmployeeId", typeof(int));
            dt.Columns.Add("ФИО", typeof(string));
            dt.Columns.Add("Должность", typeof(string));
            dt.Columns.Add("Подразделение", typeof(string));
            dt.Columns.Add("Кабинет", typeof(string));
            dt.Columns.Add("Телефоны", typeof(string));
            dt.Columns.Add("Emails", typeof(string));

            string baseSql = @"
SELECT 
    s.[Идентификатор] AS EmployeeId,
    s.[ФИО],
    d.[НазваниеДолжности] AS Должность,
    p.[НазваниеОтдела] AS Подразделение,
    ISNULL(s.[Корпус], '') + ' / ' + ISNULL(s.[НомерКабинета], '') AS Кабинет
FROM [Сотрудники] s
INNER JOIN [Должности] d ON s.[ИдДолжности] = d.[Идентификатор]
INNER JOIN [Подразделения] p ON s.[ИдПодразделения] = p.[Идентификатор]";

            if (!string.IsNullOrWhiteSpace(search))
            {
                baseSql += @"
WHERE s.[ФИО] LIKE @search
   OR d.[НазваниеДолжности] LIKE @search
   OR p.[НазваниеОтдела] LIKE @search
   OR EXISTS (
        SELECT 1 FROM [Контакты] c 
        WHERE c.[ИдСотрудника] = s.[Идентификатор] 
          AND c.[Значение] LIKE @search
   )";
            }

            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(baseSql, conn))
                {
                    if (!string.IsNullOrWhiteSpace(search))
                        cmd.Parameters.Add("@search", SqlDbType.NVarChar).Value = $"%{search}%";

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            object empIdObj = reader["EmployeeId"];
                            if (empIdObj == DBNull.Value || empIdObj == null)
                            {
                                // Пропустить или обработать ошибку
                                continue;
                            }
                            int empId = Convert.ToInt32(empIdObj);
                            string fio = reader["ФИО"].ToString();
                            string position = reader["Должность"].ToString();
                            string dept = reader["Подразделение"].ToString();
                            string room = reader["Кабинет"].ToString();

                            var contacts = GetContacts(empId);
                            dt.Rows.Add(empId, fio, position, dept, room, contacts.Item1, contacts.Item2);
                        }
                    }
                }
            }

            dataGridView1.DataSource = dt;
        }

        private (string phones, string emails) GetContacts(int employeeId)
        {
            var phones = new System.Collections.Generic.List<string>();
            var emails = new System.Collections.Generic.List<string>();

            string sql = @"
SELECT c.[Значение], t.[ЭтоТелефон]
FROM [Контакты] c
INNER JOIN [ТипыКонтактов] t ON c.[ИдТипаКонтакта] = t.[Идентификатор]
WHERE c.[ИдСотрудника] = @empId";

            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add("@empId", SqlDbType.Int).Value = employeeId;
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string value = reader["Значение"].ToString();
                            object isPhoneObj = reader["ЭтоТелефон"];
                            bool isPhone = isPhoneObj != DBNull.Value &&
                                           (isPhoneObj.ToString().Equals("1", StringComparison.OrdinalIgnoreCase) ||
                                            isPhoneObj.ToString().Equals("True", StringComparison.OrdinalIgnoreCase) ||
                                            Convert.ToBoolean(isPhoneObj));
                            if (isPhone)
                                phones.Add(value);
                            else
                                emails.Add(value);
                        }
                    }
                }
            }

            return (string.Join(", ", phones), string.Join(", ", emails));
        }

        // === Обработчики кнопок ===

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadAllEmployees(textBox1.Text.Trim());
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            LoadAllEmployees();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Проверяем, что кликнули по кнопке и по существующей строке
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Проверяем, что это столбец кнопки "Редактировать"
                if (dataGridView1.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
                {
                    // Получаем ID сотрудника из скрытого столбца "EmployeeId"
                    int empId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["EmployeeId"].Value);

                    // Проверяем права: админ — может всех, абонент — только себя
                    bool canEdit = (CurrentUserRole == "Администратор") || (CurrentEmployeeId == empId);

                    if (canEdit)
                    {
                        // 🔥 ВОТ ЭТА СТРОКА ОТКРЫВАЕТ ФОРМУ РЕДАКТИРОВАНИЯ:
                        var editForm = new EmployeeEditForm(empId);
                        if (editForm.ShowDialog() == DialogResult.OK)
                        {
                            // После успешного сохранения — обновляем таблицу
                            LoadAllEmployees();
                        }
                    }
                    else
                    {
                        MessageBox.Show("У вас нет прав на редактирование этой карточки.", "Доступ запрещён",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void мойПрофильToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message =
                $"👨‍💼 Вы вошли как:\n" +
                $"ФИО: {CurrentUserLogin}\n" +
                $"Роль: {CurrentUserRole}\n" +
                $"ID сотрудника: {CurrentEmployeeId}\n\n" +
                $"Дата входа: {DateTime.Now:dd.MM.yyyy HH:mm}";

            MessageBox.Show(this, message, "Мой профиль",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Пустые обработчики (можно удалить)
        private void файлToolStripMenuItem_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void toolStripStatusLabel1_Click(object sender, EventArgs e) { }

        private void btn_button_Click(object sender, EventArgs e)
        {
            // Открываем редактирование СВОЕЙ карточки
            var editForm = new EmployeeEditForm(CurrentEmployeeId);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                LoadAllEmployees(); // обновить таблицу
            }
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message =
                "Телефонный справочник предприятия\n" +
                "Версия: 1.0\n" +
                "Автор: Потанина Д.А.\n" +
                "Год разработки: 2025\n\n" +
                "Проект выполнен в рамках\n" +
                "производственной практики.";

            MessageBox.Show(this, message, "О программе",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
}